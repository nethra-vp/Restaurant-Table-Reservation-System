// server.js
import express from 'express';
import bodyParser from 'body-parser';
import { Sequelize } from 'sequelize';
import tableRoutes from './routes/tableRoutes.js'; // assuming you have routes in this folder

// Initialize Express app
const app = express();
app.use(bodyParser.json());

// Initialize Sequelize
const sequelize = new Sequelize('restaurant_db', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
});

// Test database connection
try {
  await sequelize.authenticate();
  console.log('Connection has been established successfully.');
} catch (error) {
  console.error('Unable to connect to the database:', error);
}

// Import models and sync
import Table from './models/tableModel.js'; // ensure this path is correct
Table.initModel(sequelize); // if your model uses a custom init function
await sequelize.sync({ alter: true }); // or { force: true } to reset tables

// Routes
app.use('/tables', tableRoutes);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

export default sequelize;
